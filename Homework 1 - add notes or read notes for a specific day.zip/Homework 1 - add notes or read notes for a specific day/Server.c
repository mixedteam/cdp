#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* portul folosit */
#define PORT 2087

/* codul de eroare returnat de anumite apeluri */
extern int errno;

int main ()
{
  struct sockaddr_in server;	// structura folosita de server
  struct sockaddr_in from;
  char msg[100];		//mesajul primit de la client
  char data[100];

  char msgrasp[100]=" ";        //mesaj de raspuns pentru client
  int sd;			//descriptorul de socket 

  /* crearea unui socket */
  if ((sd = socket (AF_INET, SOCK_STREAM, 0)) == -1)
    {
      perror ("[server]Eroare la socket().\n");
      return errno;
    }

  /* pregatirea structurilor de date */
  bzero (&server, sizeof (server));
  bzero (&from, sizeof (from));
  
  /* umplem structura folosita de server */
  /* stabilirea familiei de socket-uri */
    server.sin_family = AF_INET;	
  /* acceptam orice adresa */
    server.sin_addr.s_addr = htonl (INADDR_ANY);
  /* utilizam un port utilizator */
    server.sin_port = htons (PORT);
  
  /* atasam socketul */
  if (bind (sd, (struct sockaddr *) &server, sizeof (struct sockaddr)) == -1)
    {
      perror ("[server]Eroare la bind().\n");
      return errno;
    }

  /* punem serverul sa asculte daca vin clienti sa se conecteze */
  if (listen (sd, 5) == -1)
    {
      perror ("[server]Eroare la listen().\n");
      return errno;
    }

  /* servim in mod iterativ clientii... */
  while (1)
  {
    int client;
    int length = sizeof (from);

    printf ("[server]Asteptam la portul %d...\n",PORT);
    fflush (stdout);

    /* acceptam un client (stare blocanta pina la realizarea conexiunii) */
    client = accept (sd, (struct sockaddr *) &from, &length);

    /* eroare la acceptarea conexiunii de la un client */
    if (client < 0)
    {
    perror ("[server]Eroare la accept().\n");
    continue;
    }

    /* s-a realizat conexiunea, se astepta mesajul */
    bzero (msg, 100);
    bzero(data,100);
    printf ("[server]Asteptam mesajul...\n");
    fflush (stdout);


    if (read (client, msg, 100) <= 0)
    {
      perror ("[server]Eroare la read() de la client.\n");
      close (client); /* inchidem conexiunea cu clientul */
      continue;   /* continuam sa ascultam */
    }
    if(strcmp(msg,"new")==0)
    {
      bzero(msg,100);
      bzero(data,100);
      /* citirea mesajului */
      
      if (read (client, data, 100) <= 0)
      {
        perror ("[server]Eroare la read() de la client.\n");
        close (client); /* inchidem conexiunea cu clientul */
        continue;   /* continuam sa ascultam */
      }
      if (read (client, msg, 100) <= 0)
      {
        perror ("[server]Eroare la read() de la client.\n");
        close (client); /* inchidem conexiunea cu clientul */
        continue;   /* continuam sa ascultam */
      }

      printf ("[server]Data: %s", data);
      printf ("[server]Notita noua: %s", msg);

      FILE *dataBase = fopen("dataBase.txt", "a");
      bzero(msgrasp,100);

      if (fprintf(dataBase,data,sizeof(data)) <= 0)
      {
        ferror (dataBase);
        strcat(msgrasp,"Serverul a intampinat o problema!");
      }
      else
      {
        if (fprintf(dataBase,msg,sizeof(msg)) <= 0)
        {
          ferror (dataBase);
          strcat(msgrasp,"Serverul a intampinat o problema!");
        }
        else
        {
          strcat(msgrasp,"Notita adaugata cu succes!");
        }
      }
      fclose(dataBase);
    }
    else
    {
      if(strcmp(msg,"read")==0)
      {
        bzero(msg,100);
        bzero(data,100);

        if (read (client, data, 100) <= 0)
        {
          perror ("[server]Eroare la read() de la client.\n");
          close (client); /* inchidem conexiunea cu clientul */
          continue;   /* continuam sa ascultam */
        }

        FILE *dataBase = fopen("dataBase.txt", "r");
        bzero(msgrasp,100);

        if(dataBase==NULL) 
        {
          perror("Eroare la deschiderea fisierului!");
          continue;
        }

        while(fgets(msg, sizeof(msg), dataBase)) 
        {
          if(strcmp(msg,data)==0)
          {
            if(fgets(msg, sizeof(msg), dataBase))
              strcat(msgrasp,msg);
          }
        }
        fclose(dataBase);
      }
    }

    printf("[server]Trimitem mesajul inapoi...%s\n",msgrasp);

    /* returnam mesajul clientului */
    if (write (client, msgrasp, 100) <= 0)
    {
      perror ("[server]Eroare la write() catre client.\n");
      continue;		/* continuam sa ascultam */
    }
    else printf ("[server]Mesajul a fost trasmis cu succes.\n");
    /* am terminat cu acest client, inchidem conexiunea */
    close (client);
  }				/* while */
}
